function [f_t] = func1(x1,x2)
%FUNC1 Summary of this function goes here
%   Detailed explanation goes here
global mu
mu=5;    
f_t = mu*(1-x1^2)*x2;


end

