clear all;
close all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           �ving0 - Oppgave 2
%   Modellering in MATLAB/Simulink
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Constants
my = 5;         % Design parameter
x10 = 1;        % Initial condition
x20 = 1;        % Initial condition
t_sim = 50;     % Simulation time

%% Simulate model
sim oppgave2

%% Plot
figure(1);
plot(x1(:),x2(:));      % x1 & x2 in array format
title('Grensesykel (funksjonskall)');
xlabel('X1'); ylabel('X2');
grid; axis tight;

figure(2);
plot(x3.Data,x4.Data);  % x3 & x4 in timeseries format
title('Grensesykel (blokkdiagram)');
xlabel('X1'); ylabel('X2');
grid; axis tight;


%% Delete redundant constants
clear my x10 x20 t_sim